import React, { useState, useEffect } from 'react';

const ConnectWalletButton = () => {
    return <w3m-button />
};

export default ConnectWalletButton;

