export const getTimeInUnix = (date) => {
    return Math.floor(date / 1000)
}