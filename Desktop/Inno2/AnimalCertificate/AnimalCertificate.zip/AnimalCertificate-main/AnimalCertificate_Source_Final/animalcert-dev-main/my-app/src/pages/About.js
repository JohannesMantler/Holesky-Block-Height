const About = () => {  
    return (
      <div>
        <h1>Current Block Height.</h1>
      </div>
    );
  };
  
  export default About;