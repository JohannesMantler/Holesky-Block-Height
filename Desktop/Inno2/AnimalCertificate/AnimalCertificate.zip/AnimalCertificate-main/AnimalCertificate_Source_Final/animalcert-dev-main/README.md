# animalcert-dev
this repository is for frontent changes. 
Each new push Updates our the website deployed throug Vercel.
If you are working on a frontend feature create a new branch.

# technology
we are using [tailwind](https://tailwindcss.com/docs) for css: [https://tailwindcss.com/docs](https://tailwindcss.com/docs)
we are using [wagmi](https://wagmi.sh/) for web3: [https://wagmi.sh/](https://wagmi.sh/)


## Current pages
* Main: https://animalcert-dev.vercel.app/
* Nfc: https://animalcert-dev-git-nfc-morplson.vercel.app/
